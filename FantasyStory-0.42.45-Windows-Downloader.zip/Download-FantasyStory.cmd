@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Download-FantasyStory.ps1"
pause
