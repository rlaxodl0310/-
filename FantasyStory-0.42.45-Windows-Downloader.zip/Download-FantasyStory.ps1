$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$rootUrl = 'https://raw.githubusercontent.com/rlaxodl0310/-/cf9f06cd842a35b9aee1f90c6aa61213de851ac9'
$name = 'FantasyStory-0.42.45-Windows-x64.zip'
$target = Join-Path $PSScriptRoot $name
$expected = '9e28db1e767804ac0605caf68e7ea28e360d9f4443e36cd0544704cdce187ce8'
if (Test-Path -LiteralPath $target) {
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -eq $expected) {
        Write-Host "Already downloaded: $target"
        exit 0
    }
    throw "Move the existing $name to a different folder, then retry."
}
$cache = Join-Path $PSScriptRoot 'FantasyStory-0.42.45-downloads'
[void](New-Item -ItemType Directory -Force -Path $cache)
$partial = Join-Path $cache 'assembling.zip'
$manifest = (Invoke-WebRequest -UseBasicParsing -Uri "$rootUrl/SHA256SUMS").Content
$rows = @($manifest -split '\r?\n' | Where-Object { $_.Trim() })
if ($rows.Count -ne 14) { throw 'Incomplete download manifest.' }
for ($i = 0; $i -lt $rows.Count; $i++) {
    $part = 'game.zip.part{0:00}' -f $i
    if ($rows[$i] -notmatch '^([a-f0-9]{64})  (game\.zip\.part[0-9]{2})$' -or $Matches[2] -cne $part) {
        throw 'Invalid download manifest.'
    }
    $hash = $Matches[1]
    $path = Join-Path $cache $part
    if (-not (Test-Path -LiteralPath $path) -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $hash) {
        Write-Host ('Downloading {0}/{1}' -f ($i + 1), $rows.Count)
        Invoke-WebRequest -UseBasicParsing -Uri "$rootUrl/$part" -OutFile $path
        if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $hash) {
            throw "Download checksum mismatch: $part. Run this tool again to retry."
        }
    }
}
$out = [IO.File]::Create($partial)
try {
    for ($i = 0; $i -lt $rows.Count; $i++) {
        $path = Join-Path $cache ('game.zip.part{0:00}' -f $i)
        $inputStream = [IO.File]::OpenRead($path)
        try { $inputStream.CopyTo($out) } finally { $inputStream.Dispose() }
    }
} finally { $out.Dispose() }
if ((Get-FileHash -LiteralPath $partial -Algorithm SHA256).Hash -ne $expected) { throw 'Full game checksum mismatch.' }
Move-Item -LiteralPath $partial -Destination $target
Write-Host "Downloaded: $target"
