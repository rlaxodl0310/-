"""Local reference-image inpainting studio. White mask pixels select edits."""
import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from PIL import Image, ImageDraw, ImageOps, ImageTk


def merge_result(original, generated, mask):
    if original.size != mask.size or original.size != generated.size:
        raise ValueError("원본·결과·마스크 크기가 일치해야 합니다.")
    return Image.composite(generated.convert("RGBA"), original.convert("RGBA"), mask.convert("L"))


class Studio:
    def __init__(self, root):
        self.root = root
        root.title("Reference Studio · 로컬 부분 편집")
        root.geometry("1100x850")
        self.original = self.mask = self.result = None
        self.events = queue.Queue()
        self.busy = False
        self.model = tk.StringVar()
        self.prompt = tk.StringVar()
        self.brush = tk.IntVar(value=24)
        self.status = tk.StringVar(value="원본을 열고 수정할 부분을 흰색으로 칠하세요.")
        bar = ttk.Frame(root)
        bar.pack(fill="x", padx=12, pady=8)
        for title, command in [
            ("원본 열기", self.open_image), ("모델 폴더", self.choose_model),
            ("마스크 초기화", self.clear_mask), ("원본 보기", self.show_original),
            ("결과 보기", self.show_result), ("PNG 저장", self.save),
        ]:
            ttk.Button(bar, text=title, command=command).pack(side="left", padx=3)
        ttk.Label(root, textvariable=self.model).pack(anchor="w", padx=16)
        row = ttk.Frame(root)
        row.pack(fill="x", padx=12, pady=8)
        ttk.Label(row, text="수정 요청").pack(side="left")
        ttk.Entry(row, textvariable=self.prompt).pack(side="left", fill="x", expand=True, padx=8)
        self.run_button = ttk.Button(row, text="부분 수정 실행", command=self.generate)
        self.run_button.pack(side="left")
        ttk.Label(row, text="브러시").pack(side="left", padx=8)
        tk.Scale(row, from_=4, to=100, orient="horizontal", variable=self.brush).pack(side="left")
        self.canvas = tk.Canvas(root, background="#384047", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=12)
        self.canvas.bind("<Button-1>", self.paint)
        self.canvas.bind("<B1-Motion>", self.paint)
        self.canvas.bind("<Configure>", lambda event: self.render())
        ttk.Label(root, textvariable=self.status).pack(anchor="w", padx=12, pady=10)
        self.root.after(100, self.poll)

    def open_image(self):
        if self.busy:
            return
        path = filedialog.askopenfilename(filetypes=[("이미지", "*.png *.jpg *.jpeg *.webp")])
        if not path:
            return
        try:
            self.original = ImageOps.exif_transpose(Image.open(path)).convert("RGBA")
            self.mask = Image.new("L", self.original.size, 0)
            self.result = None
            self.render()
        except Exception as error:
            messagebox.showerror("열기 실패", str(error))

    def choose_model(self):
        if not self.busy:
            folder = filedialog.askdirectory(title="Diffusers 형식 SD 1.5 인페인팅 모델")
            if folder:
                self.model.set(folder)

    def clear_mask(self):
        if self.original and not self.busy:
            self.mask = Image.new("L", self.original.size, 0)
            self.result = None
            self.render()

    def show_original(self):
        self.render()

    def show_result(self):
        if self.result:
            self.render(self.result, False)

    def render(self, image=None, overlay=True):
        if self.original is None:
            return
        displayed = (image if image is not None else self.original).copy()
        if overlay and self.mask:
            tint = Image.new("RGBA", displayed.size, "#ff7b00")
            displayed = Image.composite(tint, displayed, self.mask.point(lambda n: n // 2))
        width = max(self.canvas.winfo_width(), 50)
        height = max(self.canvas.winfo_height(), 50)
        self.scale = min(width / displayed.width, height / displayed.height, 1)
        size = (max(1, round(displayed.width * self.scale)), max(1, round(displayed.height * self.scale)))
        displayed = displayed.resize(size, Image.Resampling.LANCZOS)
        self.photo = ImageTk.PhotoImage(displayed)
        self.offset = ((width - size[0]) // 2, (height - size[1]) // 2)
        self.canvas.delete("all")
        self.canvas.create_image(*self.offset, image=self.photo, anchor="nw")

    def paint(self, event):
        if self.original is None or self.busy:
            return
        x = (event.x - self.offset[0]) / self.scale
        y = (event.y - self.offset[1]) / self.scale
        if not (0 <= x < self.original.width and 0 <= y < self.original.height):
            return
        radius = self.brush.get() / self.scale / 2
        ImageDraw.Draw(self.mask).ellipse((x-radius, y-radius, x+radius, y+radius), fill=255)
        self.result = None
        self.render()

    def save(self):
        if self.result is None:
            messagebox.showinfo("저장", "생성 결과가 필요합니다.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG", "*.png")])
        if path:
            try:
                self.result.save(path)
                self.status.set("PNG 저장 완료")
            except Exception as error:
                messagebox.showerror("저장 실패", str(error))

    def generate(self):
        if self.busy:
            return
        if self.original is None or not self.mask.getbbox():
            messagebox.showinfo("입력 확인", "원본을 열고 수정할 부분을 칠하세요.")
            return
        folder = Path(self.model.get())
        if not (folder / "model_index.json").is_file() or not self.prompt.get().strip():
            messagebox.showinfo("입력 확인", "로컬 인페인팅 모델 폴더와 수정 요청을 지정하세요.")
            return
        original, mask = self.original.copy(), self.mask.copy()
        prompt = self.prompt.get().strip()
        self.busy = True
        self.run_button.state(["disabled"])
        self.status.set("로컬 모델을 불러오는 중입니다. 첫 실행은 오래 걸릴 수 있습니다.")

        def work():
            pipeline = None
            try:
                import torch
                from diffusers import StableDiffusionInpaintPipeline
                device = "cuda" if torch.cuda.is_available() else "cpu"
                # Pascal GPUs have limited FP16 performance. Use float32 and CPU offload.
                pipeline = StableDiffusionInpaintPipeline.from_pretrained(
                    str(folder), local_files_only=True, torch_dtype=torch.float32,
                )
                pipeline.enable_attention_slicing()
                pipeline.enable_vae_slicing()
                if device == "cuda":
                    pipeline.enable_sequential_cpu_offload()
                rgb = Image.new("RGB", original.size, "white")
                rgb.paste(original, mask=original.getchannel("A"))
                # Letterbox preserves proportions on non-square references.
                fitted = ImageOps.contain(rgb, (512, 512))
                fitted_mask = mask.resize(fitted.size, Image.Resampling.NEAREST)
                left, top = (512-fitted.width)//2, (512-fitted.height)//2
                canvas = Image.new("RGB", (512, 512), "white")
                canvas.paste(fitted, (left, top))
                edit_mask = Image.new("L", (512, 512), 0)
                edit_mask.paste(fitted_mask, (left, top))
                output = pipeline(
                    prompt=prompt, image=canvas, mask_image=edit_mask,
                    num_inference_steps=20, guidance_scale=7,
                    generator=torch.Generator(device="cpu").manual_seed(42),
                )
                if output.nsfw_content_detected and any(output.nsfw_content_detected):
                    raise RuntimeError("모델 출력 검사에서 이미지가 보류됐습니다.")
                generated = output.images[0].crop(
                    (left, top, left+fitted.width, top+fitted.height)
                ).resize(original.size, Image.Resampling.LANCZOS)
                self.events.put(("ok", merge_result(original, generated, mask)))
            except Exception as error:
                self.events.put(("error", str(error)))
            finally:
                del pipeline
                if "torch" in locals() and torch.cuda.is_available():
                    torch.cuda.empty_cache()
        threading.Thread(target=work, daemon=True).start()

    def poll(self):
        try:
            kind, value = self.events.get_nowait()
            self.busy = False
            self.run_button.state(["!disabled"])
            if kind == "ok":
                self.result = value
                self.status.set("완료 · 칠한 부분 바깥은 원본 픽셀로 보존했습니다.")
                self.show_result()
            else:
                self.status.set("생성 실패 · 원본은 보존되어 있습니다.")
                messagebox.showerror("생성 실패", value)
        except queue.Empty:
            pass
        self.root.after(100, self.poll)


if __name__ == "__main__":
    window = tk.Tk()
    Studio(window)
    window.mainloop()
