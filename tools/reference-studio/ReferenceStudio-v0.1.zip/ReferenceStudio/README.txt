Reference Studio 0.1 — 独立したローカル画像部分編集試作
Windows 10/11, Python 3.10 64bit, NVIDIA driver.
Install.cmd installs dependencies over the internet. Start.cmd opens the desktop app.
PyTorch 2.5.1 CUDA 11.8 is selected as an initial Pascal-compatible candidate.
Actual GTX 1060 performance and driver compatibility require testing on your PC.

A locally saved Diffusers-format SD1.5 inpainting model is required separately.
Use a model whose license permits your intended use. Check its model card.
The folder must contain model_index.json and all required weights/tokenizer files.
No model weights are bundled. The app only loads local model files.
English edit descriptions are recommended for SD1.5.

Open an image, select the model folder, paint the edit region, enter a request,
then run. White mask areas are edited. Pixels outside the painted region,
including transparency, are preserved exactly by final compositing.
Save the result as PNG. Models and outputs stay local during inference.
512px letterboxed inference, batch one, float32 and sequential CPU offload.
16GB RAM / 6GB VRAM are target constraints, not verified compatibility.

Included: local inpainting UI, mask painting/reset, original/result comparison,
PNG saving, background worker and error messages.
Pending: pose changes, style-reference conditioning, sprites, model installer,
desktop EXE packaging, real Windows/GPU and UI testing.
