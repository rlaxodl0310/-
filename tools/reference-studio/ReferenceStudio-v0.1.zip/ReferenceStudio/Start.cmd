@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
echo Run Install.cmd first.
pause
exit /b 1
)
.venv\Scripts\python app.py
if errorlevel 1 pause
