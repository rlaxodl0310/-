Reference Studio v0.2 — 독립 로컬 이미지 부분 편집 시제품

준비
Windows 10/11, Python 3.10 64비트, NVIDIA 드라이버.
압축을 전부 풀고 Install.cmd 실행 후 Start.cmd 실행.
설치 과정에는 인터넷이 필요합니다.

사용
1. 환경 점검 버튼에서 Python, 라이브러리, CUDA, GPU, 디스크 용량을 확인합니다.
2. 모델 설치 버튼에서 모델 페이지와 사용 조건을 확인하고 다운로드합니다.
   수 GB를 전송합니다. 앱 디스크에 8GiB 이상 여유 공간을 준비하세요.
   실패하면 같은 버튼으로 다시 다운로드할 수 있습니다.
3. 원본 열기, 수정 영역 칠하기, 수정 요청 입력, 부분 수정 실행.
   SD1.5는 영어 요청을 권장합니다.
4. 원본/결과 보기로 비교하고 PNG 저장.
   칠한 영역 바깥의 원본 픽셀과 투명도는 최종 합성에서 보존됩니다.

모델
stable-diffusion-v1-5/stable-diffusion-inpainting
고정 리비전 8a4288a76071f7280aedbdb3253bdb9e9d5d84bb
https://huggingface.co/stable-diffusion-v1-5/stable-diffusion-inpainting
별도 학습 없이 공개 모델을 실행합니다. 모델 가중치는 ZIP에 포함하지 않습니다.
다운로드 경로 models/sd15-inpainting. 필요한 모델 형식은 Diffusers입니다.
생성 실행에는 로컬 파일만 사용합니다. 모델의 기본 출력 검사는 유지합니다.

검증 범위
코드 구문, 수정 영역 바깥 픽셀 보존, 모델 다운로드 파일 선택 검사.
실제 모델 전체 다운로드와 생성, Windows UI 및 GTX 1060 실행은 미검증입니다.
PyTorch 2.5.1 CUDA 11.8은 GTX 1060 호환 시험을 위한 초기 구성입니다.
512x512 한 장, 비율 보존, float32, CPU 오프로딩.
속도와 메모리 사용은 실제 장치에서 확인해야 합니다.
자세 변경, SD/도트 애니메이션, 그림체 참조 기능, EXE 배포는 아직 구현 전입니다.
