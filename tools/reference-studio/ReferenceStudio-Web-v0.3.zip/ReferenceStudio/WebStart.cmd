@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
echo Run Install.cmd first.
pause
exit /b 1
)
.venv\Scripts\python web_server.py
if errorlevel 1 pause
