"""Pinned model installation and local environment checks."""
import importlib
import platform
import shutil
from pathlib import Path

MODEL_ID = "stable-diffusion-v1-5/stable-diffusion-inpainting"
REVISION = "8a4288a76071f7280aedbdb3253bdb9e9d5d84bb"
MODEL_URL = "https://huggingface.co/" + MODEL_ID
MODEL_DIR = Path(__file__).resolve().parent / "models" / "sd15-inpainting"


def diagnostics():
    lines = [f"OS: {platform.system()} {platform.release()}",
             f"Python: {platform.python_version()}",
             f"앱 저장 디스크 여유: {shutil.disk_usage(Path(__file__).parent).free / 2**30:.1f} GiB"]
    for name in ("PIL", "torch", "diffusers", "transformers", "accelerate"):
        try:
            module = importlib.import_module(name)
            lines.append(f"{name}: {getattr(module, '__version__', '설치됨')}")
        except Exception as error:
            lines.append(f"{name}: 불러오기 실패 ({error})")
    try:
        import torch
        lines.append(f"CUDA 사용 가능: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            props = torch.cuda.get_device_properties(0)
            lines.extend([f"GPU: {props.name}",
                          f"VRAM: {props.total_memory / 2**30:.1f} GiB",
                          f"CUDA 아키텍처: {props.major}.{props.minor}"])
    except Exception as error:
        lines.append(f"GPU 점검 실패: {error}")
    return "\n".join(lines)


def install_model():
    from huggingface_hub import snapshot_download
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    # Download one weight format only. Failed downloads can resume on the next attempt.
    if shutil.disk_usage(MODEL_DIR).free < 8 * 2**30:
        raise RuntimeError("모델 다운로드 전 앱 디스크에 8GiB 이상을 확보하세요.")
    snapshot_download(
        repo_id=MODEL_ID, revision=REVISION, local_dir=str(MODEL_DIR),
        allow_patterns=["model_index.json", "*/config.json", "scheduler/*.json",
                        "tokenizer/*", "*/model.fp16.safetensors",
                        "*/diffusion_pytorch_model.fp16.safetensors"],
    )
    if not (MODEL_DIR / "model_index.json").is_file():
        raise RuntimeError("모델 구성 파일을 확인할 수 없습니다.")
    return str(MODEL_DIR)
