import queue
from pathlib import Path
from PIL import Image, ImageOps

def merge_result(original, generated, mask):
    if original.size != mask.size or original.size != generated.size:
        raise ValueError('원본·결과·마스크 크기가 일치해야 합니다.')
    return Image.composite(generated.convert('RGBA'), original.convert('RGBA'), mask.convert('L'))

class Runner:
    def __init__(self):
        self.events = queue.Queue()

def generate(original, mask, folder, prompt):
    self = Runner()
    def work():
        pipeline = None
        try:
            import torch
            from diffusers import StableDiffusionInpaintPipeline
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            pipeline = StableDiffusionInpaintPipeline.from_pretrained(str(folder), local_files_only=True, torch_dtype=torch.float32, variant='fp16' if (folder / 'unet' / 'diffusion_pytorch_model.fp16.safetensors').is_file() else None, use_safetensors=True)
            pipeline.enable_attention_slicing()
            pipeline.enable_vae_slicing()
            if device == 'cuda':
                pipeline.enable_sequential_cpu_offload()
            rgb = Image.new('RGB', original.size, 'white')
            rgb.paste(original, mask=original.getchannel('A'))
            fitted = ImageOps.contain(rgb, (512, 512))
            fitted_mask = mask.resize(fitted.size, Image.Resampling.NEAREST)
            left, top = ((512 - fitted.width) // 2, (512 - fitted.height) // 2)
            canvas = Image.new('RGB', (512, 512), 'white')
            canvas.paste(fitted, (left, top))
            edit_mask = Image.new('L', (512, 512), 0)
            edit_mask.paste(fitted_mask, (left, top))
            output = pipeline(prompt=prompt, image=canvas, mask_image=edit_mask, num_inference_steps=20, guidance_scale=7, generator=torch.Generator(device='cpu').manual_seed(42))
            if output.nsfw_content_detected and any(output.nsfw_content_detected):
                raise RuntimeError('모델 출력 검사에서 이미지가 보류됐습니다.')
            generated = output.images[0].crop((left, top, left + fitted.width, top + fitted.height)).resize(original.size, Image.Resampling.LANCZOS)
            self.events.put(('ok', merge_result(original, generated, mask)))
        except Exception as error:
            self.events.put(('error', str(error)))
        finally:
            del pipeline
            if 'torch' in locals() and torch.cuda.is_available():
                torch.cuda.empty_cache()
    work()
    kind, value = self.events.get()
    if kind == "error":
        raise RuntimeError(value)
    return value
