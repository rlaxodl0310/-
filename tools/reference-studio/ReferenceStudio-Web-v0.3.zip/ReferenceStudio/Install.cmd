@echo off
cd /d "%~dp0"
py -3.10 -m venv .venv
if errorlevel 1 goto fail
.venv\Scripts\python -m pip install torch==2.5.1 torchvision==0.20.1 --index-url https://download.pytorch.org/whl/cu118
if errorlevel 1 goto fail
.venv\Scripts\python -m pip install -r requirements.txt
if errorlevel 1 goto fail
echo Installation completed. Open Start.cmd.
pause
exit /b 0
:fail
echo Installation failed. Python 3.10 and an NVIDIA driver are required.
pause
exit /b 1
