(function (root) {
  function validate(project) {
    if (!project || project.format !== 'reference-studio' || project.version !== 1)
      throw Error('지원하지 않는 프로젝트 형식입니다.');
    for (const name of ['image', 'mask']) {
      if (typeof project[name] !== 'string' || !project[name].startsWith('data:image/png;base64,'))
        throw Error('원본과 마스크 PNG가 필요합니다.');
    }
    if (typeof project.prompt !== 'string' || project.prompt.length > 4000)
      throw Error('수정 요청을 확인하세요.');
    if (project.result !== null && (typeof project.result !== 'string' || !project.result.startsWith('data:image/png;base64,')))
      throw Error('결과 PNG 형식 오류');
    const o = project.options;
    if (!o || !Number.isInteger(o.seed) || o.seed < 0 || o.seed > 4294967295 ||
        !Number.isInteger(o.steps) || o.steps < 10 || o.steps > 40 ||
        !Number.isFinite(o.strength) || o.strength < .2 || o.strength > 1)
      throw Error('생성 설정 값이 올바르지 않습니다.');
    return project;
  }
  root.StudioProject = {validate};
  if (typeof module !== 'undefined') module.exports = root.StudioProject;
})(globalThis);
