import math


def validate_options(data):
    values = {"seed": data.get("seed", 42), "steps": data.get("steps", 20),
              "strength": data.get("strength", 0.75)}
    if type(values["seed"]) is not int or not 0 <= values["seed"] <= 4294967295:
        raise ValueError("시드는 0~4294967295 정수여야 합니다.")
    if type(values["steps"]) is not int or not 10 <= values["steps"] <= 40:
        raise ValueError("생성 단계는 10~40 정수여야 합니다.")
    strength = values["strength"]
    if type(strength) not in (int, float) or not math.isfinite(strength) or not 0.2 <= strength <= 1:
        raise ValueError("변경 강도는 0.2~1이어야 합니다.")
    return values
