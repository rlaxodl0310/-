"""Loopback-only web UI for the local image editor."""
import base64
import io
import json
import secrets
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from PIL import Image, ImageOps
from generation_options import validate_options
from model_setup import MODEL_DIR, MODEL_URL, diagnostics, install_model

ROOT = Path(__file__).resolve().parent
TOKEN = secrets.token_urlsafe(32)
LOCK = threading.Lock()
STATE = {"busy": False, "message": "원본을 열고 수정할 부분을 칠하세요.", "result": None}
Image.MAX_IMAGE_PIXELS = 16_000_000


def decode_image(value, mode):
    if not isinstance(value, str) or not value.startswith("data:image/png;base64,"):
        raise ValueError("PNG 입력이 필요합니다.")
    raw = base64.b64decode(value.split(",", 1)[1], validate=True)
    with Image.open(io.BytesIO(raw)) as source:
        source.load()
        if source.width * source.height > 16_000_000:
            raise ValueError("이미지는 1600만 픽셀 이내로 준비하세요.")
        return ImageOps.exif_transpose(source).convert(mode)


def execute(kind, data):
    try:
        if kind == "install":
            install_model()
            message = "모델 설치 완료"
            result = None
        elif kind == "diagnostics":
            message = diagnostics()
            result = None
        else:
            original = decode_image(data.get("image"), "RGBA")
            mask = decode_image(data.get("mask"), "L")
            if mask.size != original.size or not mask.getbbox():
                raise ValueError("원본 크기의 마스크에 수정 영역을 칠하세요.")
            prompt = data.get("prompt", "").strip()
            if not prompt or len(prompt) > 4000:
                raise ValueError("수정 요청은 1~4000자로 입력하세요.")
            if not (MODEL_DIR / "model_index.json").is_file():
                raise ValueError("먼저 모델 설치를 실행하세요.")
            from engine import generate
            options = validate_options(data)
            image = generate(original, mask, MODEL_DIR, prompt, **options)
            output = io.BytesIO()
            image.save(output, format="PNG")
            result = "data:image/png;base64," + base64.b64encode(output.getvalue()).decode()
            message = "완료 · 칠한 영역 바깥의 원본 픽셀을 보존했습니다."
        with LOCK:
            STATE.update(busy=False, message=message, result=result)
    except Exception as error:
        with LOCK:
            STATE.update(busy=False, message="실패 · " + str(error), result=None)


class Handler(BaseHTTPRequestHandler):
    def send(self, code, body, content_type="application/json; charset=utf-8"):
        encoded = body if isinstance(body, bytes) else body.encode()
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(encoded)

    def allowed(self):
        return self.headers.get("Host") == f"127.0.0.1:{self.server.server_port}"

    def do_GET(self):
        if not self.allowed():
            self.send(403, "{}")
            return
        if self.path == "/":
            page = (ROOT / "web" / "index.html").read_text().replace("__TOKEN__", TOKEN)
            self.send(200, page, "text/html; charset=utf-8")
        elif self.path == "/project.js":
            self.send(200, (ROOT / "web" / "project.js").read_bytes(), "text/javascript; charset=utf-8")
        elif self.path == "/api/status" and self.headers.get("X-Studio-Token") == TOKEN:
            with LOCK:
                snapshot = dict(STATE)
            self.send(200, json.dumps(snapshot, ensure_ascii=False))
        else:
            self.send(404, "{}")

    def do_POST(self):
        if not self.allowed() or self.headers.get("X-Studio-Token") != TOKEN:
            self.send(403, "{}")
            return
        kind = self.path.removeprefix("/api/")
        if kind not in ("generate", "install", "diagnostics"):
            self.send(404, "{}")
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 32 * 1024 * 1024:
                raise ValueError("요청 크기는 32MiB 이하여야 합니다.")
            data = json.loads(self.rfile.read(length))
            if not isinstance(data, dict):
                raise ValueError("입력 형식 오류")
            with LOCK:
                if STATE["busy"]:
                    self.send(409, json.dumps({"error": "처리 중입니다."}))
                    return
                STATE.update(busy=True, result=None, message="처리 중 · " + kind)
            threading.Thread(target=execute, args=(kind, data), daemon=True).start()
            self.send(202, "{}")
        except Exception as error:
            self.send(400, json.dumps({"error": str(error)}))


if __name__ == "__main__":
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    url = f"http://127.0.0.1:{server.server_port}"
    print("Reference Studio Web: " + url)
    webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()
