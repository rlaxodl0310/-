﻿이세계 기록 v0.42.78 소형 패치

대상: Windows x64 v0.42.77 공식 설치본 및 소형 패치 적용본.
게임을 저장하고 종료한 뒤 ZIP 전체를 풀고 FantasyStoryPatch.cmd를 실행하세요.
설치 위치를 묻는 경우 기존 FantasyStory.exe를 선택하세요.
