﻿$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $root = $PSScriptRoot
    Add-Type -Path @((Join-Path $root 'PatchCore.cs'),(Join-Path $root 'InstallationLocator.cs')) -ReferencedAssemblies @('System','System.Core','System.Runtime.Serialization','System.Windows.Forms','System.Drawing')
    $found = [InstallationLocator]::Discover($root)
    if ($found.Count -eq 1) { $folder = $found[0] }
    else {
        $picker = New-Object System.Windows.Forms.OpenFileDialog
        $picker.Title = '업데이트할 FantasyStory.exe 선택'
        $picker.Filter = '이세계 기록|FantasyStory.exe'
        if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }
        $folder = [InstallationLocator]::Resolve($picker.FileName)
    }
    if ([InstallationLocator]::Running($folder)) { throw '게임을 저장하고 종료한 뒤 패치를 다시 실행해 주세요.' }
    $manifest = [PatchCore]::Read((Join-Path $root 'manifest.json'))
    $installed = [PatchCore]::InstalledVersion($folder)
    if ([version]$installed -ge [version]$manifest.version) {
        [void][System.Windows.Forms.MessageBox]::Show('이미 이 버전 이상의 게임이 설치되어 있습니다.','이세계 기록')
        exit 0
    }
    if ($installed -ne $manifest.minimumVersion) { throw ('이 패치에는 v' + $manifest.minimumVersion + ' 설치본이 필요합니다.') }
    $plan = Get-Content -Raw -LiteralPath (Join-Path $root 'delta.json') | ConvertFrom-Json
    $basePath = Join-Path $folder 'resources\app.asar'
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $basePath).Hash -ne $plan.baseSha256) {
        throw 'The installed app.asar differs from the standard 0.42.46 patch.'
    }
    $rebuilt = [System.IO.Path]::GetTempFileName()
    try {
        $baseStream = [System.IO.File]::OpenRead($basePath)
        try {
            $deltaStream = [System.IO.File]::OpenRead((Join-Path $root 'delta.bin'))
            try {
                $outputStream = [System.IO.File]::Create($rebuilt)
                try {
                    $buffer = New-Object byte[] 1048576
                    foreach ($run in $plan.runs) {
                        $inputStream = if ($run.source -eq 'base') { $baseStream } else { $deltaStream }
                        $inputStream.Position = [long]$run.offset
                        $remaining = [long]$run.length
                        while ($remaining -gt 0) {
                            $count = $inputStream.Read($buffer, 0, [int][Math]::Min($remaining, $buffer.Length))
                            if ($count -le 0) { throw 'Incomplete patch data.' }
                            $outputStream.Write($buffer, 0, $count)
                            $remaining -= $count
                        }
                    }
                } finally { $outputStream.Dispose() }
            } finally { $deltaStream.Dispose() }
        } finally { $baseStream.Dispose() }
        [void][PatchCore]::Apply($folder,$rebuilt,$manifest)
    } finally { Remove-Item -LiteralPath $rebuilt -Force }
    [InstallationLocator]::Remember($folder)
    [void][System.Windows.Forms.MessageBox]::Show(('v' + $manifest.version + ' 업데이트 완료. 기존 파일을 백업했습니다.'),'이세계 기록')
} catch {
    [void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'업데이트하지 못했습니다')
    exit 1
}
