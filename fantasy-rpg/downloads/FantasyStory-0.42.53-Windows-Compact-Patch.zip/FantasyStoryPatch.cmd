@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ApplyPatch.ps1"
if errorlevel 1 pause
