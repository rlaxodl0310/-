﻿이세계 기록 Windows v0.42.54 업데이트
v0.42.53에서만 적용합니다.
게임을 저장하고 종료한 후 ZIP 전체를 한 폴더에 풀고 FantasyStoryPatch.cmd를 실행하세요.
설치본을 찾지 못하면 FantasyStory.exe를 선택하세요. 게임 파일만 업데이트하고 기존 파일을 백업합니다.
